import os
import re

def extract_emails_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
        content = file.read()
        # Gunakan ekspresi reguler untuk menemukan alamat email
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', content)
    return emails

def main():
    input_folder = "txt"
    output_folder = "output"

    # Pastikan folder output ada atau buat jika belum ada
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    # Meminta input nama file dari pengguna
    output_file_name = input("Save File As?: ")
    output_file_path = os.path.join(output_folder, output_file_name)

    # Buka file output dengan mode append
    with open(output_file_path, 'a', encoding='utf-8') as output_file:
        # Iterasi melalui file-file di folder input
        for filename in os.listdir(input_folder):
            if filename.endswith(".txt"):
                file_path = os.path.join(input_folder, filename)
                
                # Tampilkan pesan ekstraksi di terminal
                print(f"Extract Email From >> {filename}")
                
                # Ambil alamat email dari setiap file
                emails = extract_emails_from_file(file_path)
                
                # Tulis alamat email ke file output
                for email in emails:
                    output_file.write(email + '\n')

    print(f"email berhasil diambil dan disimpan di {output_file_path}")

if __name__ == "__main__":
    main()
