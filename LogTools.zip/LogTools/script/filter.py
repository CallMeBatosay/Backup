import os

# Tentukan path folder tempat file-file .txt berada
folder_path = 'txt'

# Minta pengguna untuk memasukkan kata kunci pencarian
search_keywords = input("Search Keyword ? (pisahkan dengan tanda koma): ").split(',')

# Minta pengguna untuk memasukkan nama file tujuan
output_file_name = input("Save File As ?: ")

# Membuka file results.txt untuk ditulis dengan menentukan codec UTF-8
with open("results.txt", 'a', encoding='utf-8') as result_file:

    # Loop melalui semua file dalam folder
    for filename in os.listdir(folder_path):
        if filename.endswith('.txt'):
            file_path = os.path.join(folder_path, filename)

            # Membuka setiap file .txt dalam mode binary
            with open(file_path, 'rb') as file:
                try:
                    # Membaca semua baris dalam file dengan mendekode menggunakan UTF-8 dengan mengabaikan kesalahan
                    lines = file.read().decode('utf-8', errors='ignore').splitlines()
                except UnicodeDecodeError:
                    print(f"Error decoding file: {file_path}")
                    continue

            # Loop melalui setiap baris dalam file
            for line in lines:
                # Memeriksa apakah setidaknya satu kata kunci ada dalam baris
                if any(keyword in line for keyword in search_keywords):
                    # Menyimpan baris yang memenuhi kondisi ke dalam file tujuan
                    result_file.write(line + '\n')

                    # Juga menyimpan baris yang cocok ke dalam file yang ditentukan pengguna
                    with open(output_file_name, 'a', encoding='utf-8') as custom_result_file:
                        custom_result_file.write(line + '\n')
