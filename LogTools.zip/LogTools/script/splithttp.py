import os

def proses_folder_txt(folder_path):

    nonhttp_file_path = os.path.join(os.path.dirname(folder_path), "nonhttp.txt")
    print(f"Creating {nonhttp_file_path}")

    with open(nonhttp_file_path, "w", encoding="utf-8", errors="ignore") as nonhttp_file:
        pass  

    for file_name in os.listdir(folder_path):
        if file_name.endswith(".txt"):
            file_path = os.path.join(folder_path, file_name)
            proses_file(file_path, nonhttp_file_path)

def proses_file(input_file_path, nonhttp_file_path):
    print(f"Processing file: {input_file_path}")

    with open(input_file_path, "r", encoding="utf-8", errors="ignore") as input_file:
        lines = input_file.readlines()

    with open(input_file_path, "w", encoding="utf-8", errors="ignore") as input_file:
        with open(nonhttp_file_path, "a", encoding="utf-8", errors="ignore") as nonhttp_file:
            for line in lines:
                if not line.strip().startswith("http"):
                    nonhttp_file.write(line)
                else:
                    input_file.write(line)

folder_path_txt = "txt"
full_folder_path = os.path.abspath(folder_path_txt)
proses_folder_txt(full_folder_path)
