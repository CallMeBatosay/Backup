import os
import re
from urllib.parse import urlparse

TXT_DIR = './txt'

def load_files():
    return os.listdir(TXT_DIR)

def clean_content(line):
    try:
        line = line.strip('/')
        parser = urlparse(line)

        path = parser.path

        if ':' in path:
            splitted = path.split(':')
            if len(splitted) == 3:
                path, username, password = splitted
                url = f'{parser.scheme}://{parser.netloc}{path}'
                return (
                    url, username, password
                )
    except KeyboardInterrupt:
        exit()
    except ValueError:
        return False

def clean_content_regex(content):
    content = re.sub(r'\s\d+\s', ' ', content)
    content = re.sub(r'\s\s+', ' ', content)
    return content

def extract_content(file_name):
    file_name = os.path.join(TXT_DIR, file_name)
    result = []
    with open(file_name, 'r', encoding='utf-8', errors='ignore') as file:
        for line in file:
            line = line.rstrip()
            content = clean_content(line)
            if not content:
                pass
            result.append(content)
    return result

def clean_url(u):
    u = u.strip('/')
    if "://" not in u:
        u = 'http://' + u
    parser = urlparse(u)
    return f'{parser.netloc}'

def replace_digits(url):
    url = re.sub(r':\d+', '', url)
    return url

def main():
    keyword = input('Keyword (contoh : :2087,:2082,:2222,/cpanel.,/whm.) di pisahkan dengan koma: ').strip().replace(' ', '').split(',')

    # Allow the user to input the desired file name
    save_as = input('Save File As? (e.g., Myfile.txt): ').strip()

    print('[+] Load Files ...')

    list_files = load_files()

    print('[*] Found total {} in {}'.format(len(list_files), TXT_DIR))

    for file in list_files:
        contents = extract_content(file)
        print('[+] Processing : ', file)
        for content in contents:
            if not content:
                continue
            url, username, password = content
            if any(x in url for x in keyword):
                url = clean_url(url)
                url = replace_digits(url)
                content = f'{url} {username} {password}'
                content = clean_content_regex(content)
                print('EXTRACT DATA >> : ', content)

                # Save the content to the user-specified file
                with open(save_as, 'a', encoding='utf-8', errors='ignore') as save_file:
                    save_file.write(f'{content}\n')

if __name__ == '__main__':
    main()
