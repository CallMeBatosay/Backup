Menggunakan Python 3
list module yang harus di install : requests, bs4, colorama, paramiko,


Apa Ini Crack4All?
Ini adalah tools untuk mengekstra data dari log (orang yang kena malware/stealer dan sejenisnya) untuk selanjutnya di exploit/di crack cp/whm/ftp/ssh/directadmin
simpan log nya di folder "txt"

1. Filter V1 ?
ini untuk melakukan extract data sesuai keiginan sobat misalnya = go.id/admin/
maka akan muncul data2 domain .id path admin url/path:username:password untuk sobat coba login, gunain imajinasi sob aja

bang lu ada dapat yng valid ?
yah banyak yang valid loginnya asal tekun dan mainin imajinasi ajah sob

2. Filter V2 ?
sama seperti pertama namun untuk disini formatnya tanpa path alias "domain username password" untuk digunakan
dalam crack whm,cpanel,ftp,ssh dan directadmin
example keyword = :2087,:2082,:2222,/cpanel.,/whm.
untuk wp = /wp-login.php,/wp-admin/


3. Crack ?
sudah jelas gk usah dijelasin sob hasilnya di folder output
tinggal biarin deh nunggu hasil kalo ada yng masuk nnti ada di folder output


4. Extract Email ?
untuk mengambil daftar email dari semua file di folder txt

NOTE :
- Extract V2 hanya jika datanya url:user:password bukan untuk user:password:url atau user;password;url (disarankan memisahkan data dulu menggunakan no 4)
- hasil extract data untuk V2 mungkin bakalan ada miss, lah kok gitu? yah karena data log nya formatnya beda beda jadi bisa sob rapihin manual atau langsung gas ajah juga gpp sih 

Channel telegram gratis membagikan results Log
https://t.me/+lPBMFBj5jJE4N2Yy
https://t.me/cloudtxt
https://t.me/urllogpas
https://t.me/txtbase2
https://t.me/urlloginpass666
https://t.me/UrlLogPassFree
https://t.me/cloudtxt
https://t.me/+kB8-KwFmfaQzZmUx
https://t.me/BASEURLCLOUD
https://t.me/txtlog
https://t.me/chrono_cloud
https://t.me/OuroborosCloud

