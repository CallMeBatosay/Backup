import os
from colorama import Fore, Style

print("Welcome to CrackLog Silakan Pilih Menu:")
print(f"{Fore.RED}[1] Filter V1")
print(f"[2] Filter V2")
print(f"[3] Crack CP/WHM/SSH/FTP/DRICETADMIN")
print(f"[4] Extract Email Only")
print(f"[5] Split Http/NonHttp{Style.RESET_ALL}")

def screen_clear():
    os.system('cls')

data = {
    '1':'filter.py',
    '2':'filterv2.py',
    '3':'crack.py',
    '4':'mail.py',
    '5':'splithttp.py'
}

SCRIPT_DIR = "Script"

pilihan = input("Pilih Angka 1/2/3/4: ")
if data.get(pilihan):
    full_path = os.path.join(SCRIPT_DIR, data.get(pilihan))
    os.system(f'python {full_path}')
else:
    print('ga ada ')
